package com.cg.banking.beans;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;

import org.hibernate.annotations.Generated;
@Entity
public class Account {
	@Id
	@SequenceGenerator(name="AccountNo",initialValue=1001,allocationSize=9999,sequenceName="accountNo")
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="AccountNo")
	private int accountNo;
	private int pinNumber;
	private String accountType,accountStatus;
	private float accountBalance;
    @OneToMany(mappedBy="account")
  public Map<Integer,Transaction>transactions;
    
	public Account()
	{};
	public Account(String accountType, float accountBalance) {
		super();
		this.accountType = accountType;
		this.accountBalance = accountBalance;
	}
	public Account(int accountNo, int pinNumber, String accountType, String accountStatus, float accountBalance
			) {
		super();
		this.accountNo = accountNo;
		this.pinNumber = pinNumber;
		this.accountType = accountType;
		this.accountStatus = accountStatus;
		this.accountBalance = accountBalance;
		
	}
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public int getPinNumber() {
		return pinNumber;
	}
	public void setPinNumber(int pinNumber) {
		this.pinNumber = pinNumber;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getAccountStatus() {
		return accountStatus;
	}
	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}
	public float getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(float accountBalance) {
		this.accountBalance = accountBalance;
	}
	public Map<Integer, Transaction> getTransaction() {
		return transactions;
	}
	public void setTransaction(Map<Integer, Transaction> transaction) {
		this.transactions = transaction;
	}
	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", pinNumber=" + pinNumber + ", accountType=" + accountType
				+ ", accountStatus=" + accountStatus + ", accountBalance=" + accountBalance + ", transaction="
				+ transactions + "]";
	}
	public Account(int accountNo, int pinNumber, String accountType, String accountStatus, float accountBalance,
			Map<Integer, Transaction> transaction) {
		super();
		this.accountNo = accountNo;
		this.pinNumber = pinNumber;
		this.accountType = accountType;
		this.accountStatus = accountStatus;
		this.accountBalance = accountBalance;
		this.transactions = transaction;
	}
	
}
		