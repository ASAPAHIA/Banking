package com.cg.banking.daoservices;
import com.cg.banking.beans.Account;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
public interface AccountDAO extends JpaRepository<Account,Integer>{


}
