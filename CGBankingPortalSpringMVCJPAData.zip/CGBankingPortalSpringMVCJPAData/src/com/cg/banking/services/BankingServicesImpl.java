package com.cg.banking.services;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;

import com.cg.banking.daoservices.TransactionDAO;

import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;


@Component("bankingServices")
public class BankingServicesImpl implements BankingServices {
	@Autowired
	public AccountDAO dao;
	@Autowired
	public TransactionDAO tDao;
	Transaction transaction;
	Account account;
	Account account1;

	
	
	@Override
	public float depositAmount(int accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		Account account=dao.findById((int) accountNo).orElseThrow(()->new AccountNotFoundException("Details not fount for="+accountNo));
		if(account==null)
			throw new AccountNotFoundException("Account not found");
		if(account.getAccountStatus().equalsIgnoreCase("blocked"))
			throw new AccountBlockedException();
		else{
			account.setAccountBalance(account.getAccountBalance()+amount);
			transaction=new Transaction(amount,"Deposit");
			transaction=tDao.save(transaction);
			account.transactions.put(transaction.getTransactionId(), transaction);
		}
		return account.getAccountBalance();
	}
	@Override
	public float withdrawAmount(int accountNo, float amount, int pinNumber) 
			throws InsufficientAmountException,
			AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		account=dao.findById((int) accountNo).orElseThrow(()->new AccountNotFoundException("Details not fount for="+accountNo));
		if(account==null)
			throw new AccountNotFoundException("Account not found");
		if(account.getPinNumber()==pinNumber){
			if(amount>account.getAccountBalance())
				throw new InsufficientAmountException();
			else{
				account.setAccountBalance(account.getAccountBalance()-amount);
				transaction=new Transaction(amount,"Withdraw");
				tDao.save(transaction);
				account.transactions.put(transaction.getTransactionId(), transaction);
				dao.save(account);
			}
		}
		else {
			throw new InvalidPinNumberException();
		}
		return account.getAccountBalance();
	}
	@Override
	public boolean fundTransfer(int accountNoTo, int accountNoFrom, float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException {
		int c=3;
		do {
		account=dao.findById((int) accountNoFrom).orElseThrow(()->new AccountNotFoundException("Details not fount for="+accountNoFrom));
		account1=dao.findById((int) accountNoTo).orElseThrow(()->new AccountNotFoundException("Details not fount for="+accountNoTo));
		if(account==null || account1==null)
		{
			throw new AccountNotFoundException("Please enter valid account number");
		}
		else {
			if(account.getPinNumber()==pinNumber)
			{
				if(transferAmount>account.getAccountBalance())
					throw new InsufficientAmountException("Insufficient balance in your account");
				else
					account.setAccountBalance(account.getAccountBalance()-transferAmount);
				account1.setAccountBalance(account1.getAccountBalance()+transferAmount);
				transaction=new Transaction(transferAmount,"Transfer");
				tDao.save(transaction);
				account.transactions.put(transaction.getTransactionId(), transaction);
				account1.transactions.put(transaction.getTransactionId(),transaction);
			}
			else
			{
				c--;
				throw new InvalidPinNumberException();   }
		} }
		while(account.getPinNumber()!=pinNumber);
		return true;
	}

	@Override
	public List<Transaction> getAccountAllTransaction(int accountNo) 
			throws BankingServicesDownException, AccountNotFoundException {
		account=dao.findById((int) accountNo).orElseThrow(()->new AccountNotFoundException("Details not fount for="+accountNo));
		if(account==null)
			throw new AccountNotFoundException("No Account found");
		return new ArrayList<>(account.transactions.values());
	}
	@Override
	public String accountStatus(int accountNo) 
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
		Account account= dao.findById((int) accountNo).orElseThrow(()->new AccountNotFoundException("Details not fount for="+accountNo));
		return account.getAccountStatus();

	}
	@Override
	public void checkPin(int counter, int accountNo) throws AccountBlockedException {
		if(counter==0) {
			account.setAccountStatus("Blocked");
			throw new AccountBlockedException();
		}
		
	}
	@Override
	public Account openAccount(Account account)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
		if(account.getAccountBalance()<500) {
			throw new InvalidAmountException("enter amount above 500");
		}
		account=dao.save(account);
		return account;
	}
	@Override
	public Account getAccountDetails(int accountNo) throws BankingServicesDownException {
		
		Account account = (Account)dao.findById(accountNo).orElseThrow(()->new BankingServicesDownException("Details not fount for="+accountNo));
		return account;
	}
	
}
